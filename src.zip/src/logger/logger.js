let welcome=function()
{
    console.log('Welcome to my application. I am Moulesh and a part of FunctionUp Uranium cohort.');
}
module.exports.welcome=welcome