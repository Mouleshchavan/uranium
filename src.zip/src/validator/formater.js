let a=" functionUp  ";
let b=a.trim();
let x=b.toLowerCase();
let y=x.toUpperCase();
module.exports.b=b;
module.exports.x=x;
module.exports.y=y;